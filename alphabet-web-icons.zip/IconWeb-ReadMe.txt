
Alphabet Web Icons

by: Keith Fenske, https://kwfenske.github.io/

Outline letters and digits as program icons for Microsoft Windows or as
"favicon.ico" files on web pages (bookmark icons).

1. Icons are square, and each icon uses a fixed amount of space, with a small
empty border. No two letters are similar by reflection or rotation. Digits
don't count.

2. Icons are bitmapped from 16x16 pixels to 256x256 pixels. Icons of the same
size have the same general appearance. Sizes are 16, 20, 24, 28, 32, 40, 48,
64, 96, 128, 192, and 256 pixels.

3. The style is "structural tubing" with straight lines, rounded 90-degree
corners, a white interior, and a dark outline. This displays well on most
backgrounds.

4. Desktop web browsers need a 32x32 icon, should have a 16x16 icon, and might
use other sizes. Google Chrome (about 70% of the desktop market) resizes 32x32
to whatever it wants, and ignores other sizes.

5. Mobile web browsers use dozens of sizes that are always changing. There is
no support for mobile browsers unless they accidentally request a size listed
above.

6. Icons should look good as defined or with some resizing.

Copyright (c) 2021 by Keith Fenske. Released under GNU Public License (GPL):

These icons are free software: you can redistribute them and/or modify them
under the terms of the GNU General Public License as published by the Free
Software Foundation, either version 3 of the License or (at your option) any
later version. These icons are distributed in the hope that they will be
useful, but WITHOUT ANY WARRANTY, without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU General Public
License for more details.

You should have received a copy of the GNU General Public License along with
these icons. If not, see the http://www.gnu.org/licenses/ web page.

2021-06-23

----------
