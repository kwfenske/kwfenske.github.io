/*
  Plain Text Parse #1 - Character Map Captions to Plain Text Descriptions
  Written by: Keith Fenske, http://kwfenske.github.io/
  Thursday, 26 September 2019
  Java class name: PlainTextParse1
  Copyright (c) 2019 by Keith Fenske.  Apache License or GNU GPL.

  This is a quick-and-dirty Java 1.4 console application to extract captions
  from the Character Map data file ("CharMap4.txt") and reformat as detailed
  descriptions for an extended test version of the Plain Text data file.

  There are no parameters.  The input data file must be in the current working
  directory.  Output goes into a file called "parsed-captions.txt" encoded as
  UTF-8 text (mostly US-ASCII).  Add this to your "PlainText3.txt" data file.

  General users have no need for the PlainTextParse1 application.  THIS CODE IS
  UGLY AND SHOULD *NOT* BE USED AS THE BASIS FOR ANY OTHER PROGRAMS.

  Apache License or GNU General Public License
  --------------------------------------------
  PlainTextParse1 is free software and has been released under the terms and
  conditions of the Apache License (version 2.0 or later) and/or the GNU
  General Public License (GPL, version 2 or later).  This program is
  distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY,
  without even the implied warranty of MERCHANTABILITY or FITNESS FOR A
  PARTICULAR PURPOSE.  See the license(s) for more details.  You should have
  received a copy of the licenses along with this program.  If not, see the
  http://www.apache.org/licenses/ and http://www.gnu.org/licenses/ web pages.
*/
