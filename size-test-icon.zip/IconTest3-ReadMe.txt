
Size Test Icon - IconTest3.ico
by: Keith Fenske, https://kwfenske.github.io/
Tuesday, 29 November 2016

Way back when in Windows XP (2001), a big icon was 64x64 pixels. Now you need
256x256 plus 16x16, 32x32, 48x48, and several more depending upon a system's
DPI display setting (usually 100% for 96 DPI, 125% for 120 DPI, or 150%). There
is no guarantee that Windows will use any given size, even if defined in an
icon file. Many will be scaled down from 256x256. Others will sometimes be used
and sometimes won't. This test icon has each size labelled with the number of
pixels, with sharp edges and an outline so you can see if Windows is resizing
from another size. Defined sizes are from 8x8 to 32x32 in steps of 2, from
32x32 to 64x64 in steps of 4, from 64x64 to 128x128 in steps of 8, and from
128x128 to 256x256 in steps of 16.

This is a program icon for Microsoft Windows, and may also be a bookmark icon
on web pages in a "favicon.ico" file.

Copyright (c) 2016 by Keith Fenske. Released under the terms and conditions of
the Apache License (version 2.0 or later) and/or the GNU General Public License
(GPL, version 2 or later).

2021-09-09

----------
