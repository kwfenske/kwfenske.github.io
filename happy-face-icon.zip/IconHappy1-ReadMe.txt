
Happy Face Icon - IconHappy1.ico
by: Keith Fenske, https://kwfenske.github.io/
Thursday, 10 November 2016

Brighten up the day with this classic "happy face" icon. Available in a range
of sizes from 16x16 to 256x256 pixels. Or make your own from the Microsoft
"Wingdings" font (in the same character position as the capital letter "J").

This is a program icon for Microsoft Windows, and may also be a bookmark icon
on web pages in a "favicon.ico" file.

Copyright (c) 2016 by Keith Fenske. Released under the terms and conditions of
the Apache License (version 2.0 or later) and/or the GNU General Public License
(GPL, version 2 or later).

2021-09-09

----------
