/*
  Character Map Parse #6 - Quick-and-Dirty Extraction of Unicode Data
  Written by: Keith Fenske, http://kwfenske.github.io/
  Monday, 14 November 2016
  Java class name: CharMapParse6
  Copyright (c) 2016 by Keith Fenske.  Apache License or GNU GPL.

  This is a quick-and-dirty Java 1.4 console application to parse three data
  files with Unicode character numbers (hexadecimal) and names.  These files
  are subject to change each time the Unicode standard is revised, both in
  content and in syntax:

   1. UnicodeData.txt (standard character names)
      from: http://www.unicode.org/Public/UNIDATA/UnicodeData.txt

   2. Unihan_Readings.txt and Unihan_Variants.txt (Chinese-Japanese-Korean)
      from: http://www.unicode.org/Public/UNIDATA/Unihan.zip

  There are no parameters.  The input data files must be in the current working
  directory.  Output goes into a file called "parsed-unidata.txt" as US-ASCII
  plain text (or encoded as UTF-8) for the "CharMap4.txt" data file used by the
  CharMap4 Java application.  Some manual editing will be required:

   1. The data goes after the explanatory comments in the CharMap4.txt file.

   2. Control codes (U+0000 to U+001F and U+007F to U+009F) will have the wrong
      descriptions.  You should use the existing descriptions that were created
      by hand.  Search for "<" and ">" in the output file.

   3. There will be spurious entries for the first and last characters in large
      Unicode blocks (ranges).  Again, search for "<" and ">".

   4. Some descriptions will have incorrect capitalization.  In particular, you
      may find "Apl" instead of the correct "APL" (U+2336 to U+2395), and "Cjk"
      instead of the correct "CJK" (U+2E80 to U+31E3).

   5. Some "CJK compatibility ideograph" from U+FA0E to U+FAD9 and U+2F800 to
      U+2FA1D have default names in UnicodeData.txt that are not replaced by
      better information in the Unihan files.  See also CharMapParse7.

  Modified for Unicode 9.0.0 (2016) and still working on Unicode 11.0.0 (2018).
  CharMapParse6 replaces four older programs numbered 2 to 5.  (CharMapParse1
  does a different but related job.)  This source file should only be
  distributed with the source for CharMap4.  General users have no need for the
  CharMapParse6 application.  THIS CODE IS UGLY AND SHOULD *NOT* BE USED AS THE
  BASIS FOR ANY OTHER PROGRAMS.

  Apache License or GNU General Public License
  --------------------------------------------
  CharMapParse6 is free software and has been released under the terms and
  conditions of the Apache License (version 2.0 or later) and/or the GNU
  General Public License (GPL, version 2 or later).  This program is
  distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY,
  without even the implied warranty of MERCHANTABILITY or FITNESS FOR A
  PARTICULAR PURPOSE.  See the license(s) for more details.  You should have
  received a copy of the licenses along with this program.  If not, see the
  http://www.apache.org/licenses/ and http://www.gnu.org/licenses/ web pages.
*/
