
Generic Program Icon - IconGeneric1.ico
by: Keith Fenske, https://kwfenske.github.io/
Friday, 11 November 2016

A generic icon is a placeholder for when you need an icon but don't have time
yet to design a new one. Has various sizes from 16x16 to 256x256 pixels.

This is a program icon for Microsoft Windows, and may also be a bookmark icon
on web pages in a "favicon.ico" file.

Copyright (c) 2016 by Keith Fenske. Released under the terms and conditions of
the Apache License (version 2.0 or later) and/or the GNU General Public License
(GPL, version 2 or later).

2021-09-09

----------
