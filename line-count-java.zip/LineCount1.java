/*
  Line Count #1 - Count Number of Characters and Lines in Text File
  Written by: Keith Fenske, http://kwfenske.github.io/
  Friday, 16 August 2024
  Java class name: LineCount1
  Copyright (c) 2024 by Keith Fenske.  Apache License or GNU GPL.

  This is a Java 1.4 console application to count the number of characters and
  lines in a plain text file such as source code.  Put one or more file names
  on the command line:

    java  LineCount1  x.txt

  Text lines may end with a carriage return (CR or 0x0D), a line feed (LF or
  0x0A), or CR followed by LF.  Having LF by itself is more commonly called a
  "newline" character or NL.  If a file has a different character set than your
  system's default encoding, you should put the name of the character set as a
  "-c" option.  For example, UTF-8 is very popular with web pages:

    java  LineCount1  -cUTF-8  x.txt

  There is no graphical interface (GUI) for this program; it must be run from a
  command prompt, command shell, or terminal window.

  Apache License or GNU General Public License
  --------------------------------------------
  LineCount1 is free software and has been released under the terms and
  conditions of the Apache License (version 2.0 or later) and/or the GNU
  General Public License (GPL, version 2 or later).  This program is
  distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY,
  without even the implied warranty of MERCHANTABILITY or FITNESS FOR A
  PARTICULAR PURPOSE.  See the license(s) for more details.  You should have
  received a copy of the licenses along with this program.  If not, see the
  http://www.apache.org/licenses/ and http://www.gnu.org/licenses/ web pages.
*/

import java.io.*;                 // standard I/O
import java.text.*;               // number formatting

public class LineCount1
{
  /* constants */

  static final char CHAR_CR = 0x0D; // ASCII carriage return (CR), same as '\r'
  static final char CHAR_LF = 0x0A; // ASCII line feed (LF), same as '\n'
  static final String COPYRIGHT_NOTICE =
    "Copyright (c) 2024 by Keith Fenske.  Apache License or GNU GPL.";
  static final int EXIT_FAILURE = -1; // incorrect request or errors found
  static final int EXIT_SUCCESS = 1; // request completed successfully
  static final int EXIT_UNKNOWN = 0; // don't know or nothing really done
  static final String PROGRAM_TITLE =
    "Count Number of Characters and Lines in Text File - by: Keith Fenske";

  /* class variables */

  static String charSetName;      // character set (name of encoding)
  static NumberFormat formatComma; // formats with commas (digit grouping)
  static boolean mswinFlag;       // true if running on Microsoft Windows

/*
  main() method

  We run as a console application.  There is no graphical interface.
*/
  public static void main(String[] args)
  {
    int fileCount;                // number of files given on command line
    int i;                        // index variable
    String word;                  // one parameter from command line

    /* Initialize variables used by both console and GUI applications. */

    charSetName = null;           // by default, use local encoding
    fileCount = 0;                // no files found yet
    formatComma = NumberFormat.getInstance(); // current locale
    formatComma.setGroupingUsed(true); // use commas or digit groups
    mswinFlag = System.getProperty("os.name").startsWith("Windows");

    /* Check command-line parameters for options. */

    for (i = 0; i < args.length; i ++)
    {
      word = args[i].toLowerCase(); // easier to process if consistent case
      if (word.length() == 0)
      {
        /* Ignore empty parameters, which are more common than you might think,
        when programs are being run from inside scripts (command files). */
      }

      else if (word.equals("?") || word.equals("-?") || word.equals("/?")
        || word.equals("-h") || (mswinFlag && word.equals("/h"))
        || word.equals("-help") || (mswinFlag && word.equals("/help")))
      {
        showHelp();               // show help summary
        System.exit(EXIT_UNKNOWN); // exit application after printing help
      }

      else if (word.startsWith("-c") || (mswinFlag && word.startsWith("/c")))
      {
        charSetName = args[i].substring(2).trim(); // get character set name
        if (charSetName.length() == 0)
          charSetName = null;     // default back to local system
      }

      else if (word.startsWith("-") || (mswinFlag && word.startsWith("/")))
      {
        System.err.println("Option not recognized: " + args[i]);
        showHelp();
        System.exit(EXIT_FAILURE);
      }

      else                        // assume this is a file name
      {
        fileCount ++;             // one more file found
        processFile(args[i]);     // easier to read if method called
      }
    }

    if (fileCount == 0)
    {
      System.err.println("Missing file name(s) on command line.");
      showHelp();
      System.exit(EXIT_FAILURE);
    }
    System.exit(EXIT_SUCCESS);    // if we get here, everything is good

  } // end of main() method


/*
  processFile() method

  Count the number of characters and lines in a given text file.
*/
  static void processFile(String fileName)
  {
    int ch;                       // current input character as an integer
    long fileChars;               // number of characters in this file
    long fileLines;               // number of lines in this file
    boolean foundCr;              // found carriage return (CR), waiting for LF
    BufferedReader inputStream;   // input stream of characters
    long lineChars;               // number of characters on this line

    try                           // allow for I/O errors
    {
      /* Open the file for reading, maybe with a given character set. */

      if (charSetName == null)    // use local system's encoding?
      {
        inputStream = new BufferedReader(new FileReader(fileName));
      }
      else                        // given character set name
      {
        inputStream = new BufferedReader(new InputStreamReader(new
          FileInputStream(fileName), charSetName));
      }

      /* Read one character at a time, recognizing CR/LF pairs as a combined
      newline separator or terminator. */

      fileChars = fileLines = lineChars = 0; // clear totals
      foundCr = false;            // no pending carriage return
      while ((ch = inputStream.read()) >= 0) // read until end-of-file (-1)
      {
        fileChars ++;             // count all characters, including newlines
        if (ch == CHAR_CR)        // carriage return (CR)?
        {
          fileLines ++;           // one more line
          foundCr = true;         // CR may be followed by LF
          lineChars = 0;          // start next line as empty
        }
        else if (ch != CHAR_LF)   // everything except line feed (LF)
        {
          foundCr = false;        // not a carriage return
          lineChars ++;           // one more character on this line
        }
        else if (foundCr)         // does this LF follow CR?
        {
          foundCr = false;        // not a carriage return
          lineChars = 0;          // start next line as empty
        }
        else                      // LF without CR (newline character)
        {
          fileLines ++;           // one more line
          foundCr = false;        // not a carriage return
          lineChars = 0;          // start next line as empty
        }
      }

      /* Close the input file and print a summary. */

      inputStream.close();        // try to close input file
      if (lineChars > 0)          // last line counts if not empty
        fileLines ++;             // one more line
      System.out.println(fileName + " has " + formatComma.format(fileChars)
        + " characters in " + formatComma.format(fileLines) + " lines.");
    }
    catch (UnsupportedEncodingException uee) // subclass of IOException
    {
      System.err.println(fileName + " - unknown character set: "
        + charSetName);
      System.exit(EXIT_FAILURE);
    }
    catch (IOException ioe)       // all other file I/O errors
    {
      System.err.println(fileName + " - " + ioe.getMessage());
//    System.exit(EXIT_FAILURE);
    }
  } // end of processFile() method


/*
  showHelp() method

  Show the help summary.  This is a UNIX standard and is expected for all
  console applications, even very simple ones.
*/
  static void showHelp()
  {
    System.err.println();
    System.err.println(PROGRAM_TITLE);
    System.err.println();
    System.err.println("This is a Java console application to count the number of characters and lines");
    System.err.println("in a plain text file.");
    System.err.println();
    System.err.println("  java  LineCount1  [options]  fileNames");
    System.err.println();
    System.err.println("You may give options on the command line:");
    System.err.println();
    System.err.println("  -c# = character set name or text encoding; default is local system;");
    System.err.println("      example: -cUTF-8");
    System.err.println();
    System.err.println(COPYRIGHT_NOTICE);
//  System.err.println();

  } // end of showHelp() method

} // end of LineCount1 class

/* Copyright (c) 2024 by Keith Fenske.  Apache License or GNU GPL. */
